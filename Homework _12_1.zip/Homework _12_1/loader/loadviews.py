import json
from flask import Flask, request, Blueprint, render_template
from utils import save_picture, add_post
import logging

loader_blueprint = Blueprint('loader_blueprint', __name__, template_folder = 'templates')
logging.basicConfig(level=logging.INFO)

@loader_blueprint.route('/post')
def create_post_page():
    '''Загрузка страницы шаблона для добавления нового поста'''
    return render_template('post_form.html')

@loader_blueprint.route('/post', methods=['POST'])
def add_new_post():
    '''Реализация функции добавления нового поста, сохранения его в списке постов с загрузкой в файл json'''
    picture = request.files.get('picture')
    content = request.form.get('content')
    if not picture or not content:
        return "Не все поля заполнены"


    try: # реализована проверка ошибки на случай невозможности сохранения файла пр указанному пути
        picture_path = save_picture(picture)
        logging.info(f'Картинка сохранена')
    except:
        logging.info (f'Картинка не сохранена. Путь не найден')
        return "Картинка не сохранена. Путь не найден"

    filename = picture.filename
    file_type = filename.split ('.')[-1]
    if file_type not in ('bmp', 'jpg', 'png') :
        logging.info(f'Файл не является картинкой')
        return "Файл не является картинкой"

    new_post = {'pic':picture_path, 'content':content}
    add_post(new_post)
    post = add_post (new_post)
    with open ("posts.json", "w", encoding='utf-8') as file :
        json.dump (post, file, ensure_ascii=False)
        return render_template('post_uploaded.html', picture_path=picture_path, content=content)