from flask import Flask, request, Blueprint, render_template
from utils import load_posts, search_by_posts
import logging

main_blueprint = Blueprint('main_blueprint', __name__, template_folder = 'templates')
logging.basicConfig(level=logging.INFO)

@main_blueprint.route('/')
def main_page():
    '''Загрузка шаблона главной страницы'''
    return render_template('index.html')

@main_blueprint.route('/search')
def search_page():
    '''Создание страницы, для поиска постов по слову с проверкой на ошибку, если файл или список постов не найдены'''
    try:
        substr = request.args.get ('s', 'нет страницы для поиска')
        logging.info(f'поиск: {substr}')
        posts = search_by_posts(substr)
        return render_template('post_list.html', posts=posts, substr=substr)
    except:
        logging.info(f'Файл отсутствует, список постов не найден')
        return "Файл отсутствует, список постов не найден"

