import json

file_json = "loader/templates/posts.json"

new_post = {
    "pic": "https://images.unsplash.com/photo-1494952200529-3ceb822a75e2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=880&q=80",
    "content": "Утром отправились на катере обследовать ближайшие острова – острова в основном каменные, бесполезные и необитаемые. На обратном пути попали в бурю, и нас чуть не унесло в океан. В течение 10 минут наш катер несся к отмели, а потом мы стали дрейфовать между скал, держась за трос. Наконец погода наладилась и мы смогли совершить обратный путь. Когда уже прибыли домой, я попросил, чтобы на следующий день нам устроили на катере экскурсию по морю. Нас провели по морскому дну от одного острова к другому, показали различные интересные объекты, которые встречаются в этом районе."
}

def load_posts(file_json) :
    with open (file_json, 'r', encoding='utf-8') as file :
        posts = json.load (file)
        return posts

def add_post(post) :
   posts = load_posts (file_json)
   posts.append (post)
   return posts

post=add_post(new_post)
with open ("loader/templates/posts.json", "w", encoding='utf-8') as file:
    json.dump(post, file, ensure_ascii=False)



print(add_post(new_post))
print(len(add_post(new_post)))






