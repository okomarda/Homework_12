import json

file_json = "posts.json"

def load_posts(file_json) :
    '''Передача данных файла json в список'''
    with open (file_json, 'r', encoding='utf-8') as file :
        posts = json.load (file)
    return posts

def search_by_posts(substr) :
    '''Поиск постов по выбранному слову'''
    posts_select = []
    posts = load_posts (file_json)
    for post in posts :
        if substr.lower ( ) in post['content'].lower ( ) :
            posts_select.append (post)
    return posts_select

def save_picture(picture) :
    '''Сохранения картинки в папке uploads по критерию расширения файла'''
    filename = picture.filename
    file_type = filename.split ('.')[-1]
    if file_type not in ('bmp', 'jpg', 'png') :
        return "Файл не является картинкой"


    picture.save (f"./uploads/{filename}")
    return f'uploads/{filename}'

def add_post(post) :
   '''Добавление нового поста в список постов'''
   posts = load_posts (file_json)
   posts.append (post)
   return posts



